﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;


namespace iCamp
{
    public partial class SelectActivities : Form
    {
        public SelectActivities()
        {
            InitializeComponent();
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SelectActivities_Load(object sender, EventArgs e)
        {
            XDocument doc = XDocument.Load("XMLFILE2.xml");
            var docread = doc.Elements("data1").Elements("bunk");
            foreach (var x in docread)
            {
                comboBox1.Items.Add(x.Value);
            }
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }
            XDocument docx = XDocument.Load("XMLFILE1.xml");
            var docxread = docx.Elements("data1").Elements("item").Where(y => y.Element("bunk").Value == comboBox1.Text);
            foreach(var x in docxread)
            {
                comboBox2.Items.Add(x.Element("name").Value);
            }
            XDocument docy = XDocument.Load("XMLFILE3.xml");
            var docyread = docy.Elements("data1").Elements("date").Where(y => y.Element("value").Value.Equals(dateTimePicker1.Value.ToString("year-MM-dd"))).Elements("activity");
            if (docyread.Count() > 0)
            {
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                listBox3.Items.Clear();
                listBox4.Items.Clear();
                listBox5.Items.Clear();
                int count = 0;
                foreach (var x in docyread)
                {
                    foreach (var y in x.Elements("name"))
                    {
                        switch (count)
                        {
                            case 0:
                               listBox1.Items.Add(y.Value);
                            break;
						case 1:
					    listBox2.Items.Add(y.Value);
                            break;
					   case 2:
						listBox3.Items.Add(y.Value);
                            break;
					   case 3:
						listBox4.Items.Add(y.Value);
                            break;
						case 4:
					 listBox5.Items.Add(y.Value);
                                break;
                        }
                    }
                    count++;
                }
            }
            else
            {
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                listBox3.Items.Clear();
                listBox4.Items.Clear();
                listBox5.Items.Clear();
                listBox1.Items.Add("Drama");
                listBox2.Items.Add("Drawing");
                listBox3.Items.Add("Carpenting");
                listBox4.Items.Add("Football");
                listBox5.Items.Add("Softball");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XDocument docx = XDocument.Load("XMLFile4.xml");
            XElement root = docx.Root;
            root.Add(
                new XElement("Bunk", comboBox1.SelectedItem.ToString()),
                new XElement("Name", comboBox2.SelectedItem.ToString()),
                new XElement("Date", dateTimePicker1.Value.ToString("year-MM-dd")),
                new XElement("Activity1", listBox1.SelectedItem.ToString()),
                new XElement("Activity2", listBox2.SelectedItem.ToString()),
                new XElement("Activity3", listBox3.SelectedItem.ToString()),
                new XElement("Activity4", listBox4.SelectedItem.ToString()),
                new XElement("Activity5", listBox5.SelectedItem.ToString())
                );
            docx.Save("XMLFile4.xml");

            this.Close();


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            XDocument docy = XDocument.Load("XMLFile1.xml");
            var docyread = docy.Elements("data1").Elements("item").Where(y => y.Element("bunk").Value == comboBox1.Text);
            comboBox2.Items.Clear();
            foreach (var x in docyread)
            {
                comboBox2.Items.Add(x.Element("name").Value);
            }
            //clear the name box if changes are made into the index
            if(comboBox2.Items.Count > 0)
            {
                comboBox2.SelectedIndex = 0;
            }
            else
            {
                comboBox2.Text = "";
            }
        }

    }
}
