﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;
using System.Xml.Linq;

namespace iCamp
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        void Fillcombo()
        {

        }

        private void Register_Load(object sender, EventArgs e)
        {
            if (File.Exists("XMLFile1.xml"))
            {
                XmlSerializer xs = new XmlSerializer(typeof(Information));
                FileStream read = new FileStream("XMLFile1.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
                Information info = (Information)xs.Deserialize(read);
                textBox1.Text = info.Name;
                comboBox2.Text = info.Bunk;
                textBox3.Text = info.Nationality;
                textBox4.Text = info.StartDate;
                textBox5.Text = info.LeaveDate;
                textBox12.Text = info.PreferredName;
                textBox13.Text = info.Age;
                textBox14.Text = info.Restriction;
                textBox15.Text = info.Medications;
                textBox16.Text = info.Transportation;
                textBox6.Text = info.Name1;
                textBox8.Text = info.PhoneNo1;
                textBox10.Text = info.Email1;
                textBox7.Text = info.Name2;
                textBox9.Text = info.PhoneNo2;
                textBox11.Text = info.Email2;

                StreamReader sr = new StreamReader("data.xml");
                string line = sr.ReadLine();
                while (line != null)
                {
                    comboBox1.Items.Add(line);
                        line = sr.ReadLine();
                }

            }

            
          

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Information info = new Information();
                info.Name = textBox1.Text;
                info.Bunk = comboBox2.Text;
                info.Nationality = textBox3.Text;
                info.StartDate = textBox4.Text;
                info.LeaveDate = textBox5.Text;
                info.PreferredName = textBox12.Text;
                info.Age = textBox13.Text;
                info.Restriction = textBox14.Text;
                info.Medications = textBox15.Text;
                info.Transportation = textBox16.Text;
                info.Name1 = textBox6.Text;
                info.PhoneNo1 = textBox8.Text;
                info.Email1 = textBox10.Text;
                info.Name2 = textBox7.Text;
                info.PhoneNo2 = textBox9.Text;
                info.Email2 = textBox11.Text;
                SaveXML.SaveData(info, "data.xml");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);             
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String student = comboBox1.Text;
            comboBox1.Items.Add(student);
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
