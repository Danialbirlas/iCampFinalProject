﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;


namespace iCamp
{
    public partial class RegisterActivity : Form
    {
        public RegisterActivity()
        {
            InitializeComponent();
        }

        private void RegisterActivity_Load(object sender, EventArgs e)
        {


            XDocument docx = XDocument.Load("XMLFile3.xml");
            var docxread = docx.Elements("data1").Elements("date").Elements("activity");

            if (docxread.Count()> 0)
            {
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                listBox3.Items.Clear();
                listBox4.Items.Clear();
                listBox5.Items.Clear();

                int count = 0;
                foreach (var x in docxread)
                {
                    foreach (var y in x.Elements("name"))
                    {
                        switch (count)
                        {
                            case 0:
                               listBox1.Items.Add(y.Value);
                                break;
                            case 1:
                                listBox2.Items.Add(y.Value);
                                break;
                            case 2:
                                listBox3.Items.Add(y.Value);
                                break;
                            case 3:
                                listBox4.Items.Add(y.Value);
                                break;
                            case 4:
                                listBox5.Items.Add(y.Value);
                                break;
                            default:
                                break;
                        }

                    }
                    count++;
                }

            }

        }

        private void savetoXML(int x, string y)
        {
            XDocument docx = XDocument.Load("XMLFile3.xml");
            var docxread = docx.Elements("data1");
            int count = 0;
            foreach (var z in docxread)
            {
                if (count == x)
                {
                    z.Add(new XElement("name", y));
                }
                count++;
            }
            docx.Save("XMLFile3.xml");

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string y = comboBox1.SelectedItem.ToString();
            string z = textBox1.Text;

            switch (y)
            {
                case "Activity1":
                    {
                        savetoXML(0, z);
                        listBox1.Items.Add(z);
                        break;
                    }
                case "Activity2":
                    {
                        savetoXML(1, z);
                        listBox2.Items.Add(z);
                        break;
                    }
                case "Activity3":
                    {
                        savetoXML(2, z);
                        listBox3.Items.Add(z);
                        break;
                    }
                case "Activity4":
                    {
                        savetoXML(3, z);
                        listBox4.Items.Add(z);
                        break;
                    }
                case "Activity5":
                    {
                        savetoXML(4, z);
                        listBox5.Items.Add(z);
                        break;
                    }

                default:
                    {
                        break;
                    }


            }
        }

        private void delete_click(object sender, EventArgs e)
        {
            Button delete = (Button)sender;
            int pings = Convert.ToInt16(delete.Tag) - 1;

            ListBox[] listboxlist = { listBox1, listBox2, listBox3, listBox4, listBox5 };
            XDocument docx = XDocument.Load("XMLFile3.xml");
            var docxread = docx.Elements("data1").Elements("date").Elements("activity");
            int count = 0;
            foreach (var z in docxread)

            {
                if (count == pings)
                {
                    z.Elements("name").Where(y => y.Value == listboxlist[pings].Text).Single().Remove();
                    listboxlist[pings].Items.RemoveAt(listboxlist[pings].SelectedIndex);
                }
                count++;
            }
            docx.Save("XMLFile4.xml");


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
