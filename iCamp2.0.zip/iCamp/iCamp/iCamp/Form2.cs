﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace iCamp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //loads the document
            XDocument docx = XDocument.Load("XMLFILE1.xml");
            //reads the items
            var docxread = docx.Elements("data1").Elements("item");
            //its meant to clear the textbox
            comboBox1.Items.Clear();
            foreach (var x in docxread)
            {
                comboBox1.Items.Add(x.Element("name").Value.ToString());
            }
            //use xml data presented for the bunks to be loaded
            XDocument docy = XDocument.Load("XMLFILE2.xml");
            var docyread = docy.Elements("data1").Elements("bunk");
            foreach (var x in docyread)
            {
                comboBox2.Items.Add(x.Value);
            }
            if (comboBox2.Items.Count > 0) 
            {
                comboBox2.SelectedIndex = 0;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            XDocument docx = XDocument.Load("XMLFile1.xml");
            var docxread = docx.Elements("data1").Elements("item");
            //reads items
            var item = docxread.Where(y => y.Element("name").Value == comboBox1.Text).Single();
            //extracting camper's information 
            textBox8.Text = item.Element("name").Value;
            textBox12.Text = item.Element("nickname").Value;
            comboBox2.Text = item.Element("bunk").Value;
            textBox9.Text = item.Element("nationality").Value;
            textBox10.Text = item.Element("startdate").Value;
            textBox11.Text = item.Element("enddate").Value;
            textBox1.Text = item.Element("age").Value;
            textBox2.Text = item.Element("restriction").Value;
            textBox3.Text = item.Element("medications").Value;
            textBox4.Text = item.Element("transportaion").Value;
            textBox13.Text = item.Element("Parent1Name").Value;
            textBox14.Text = item.Element("Parent1Phone").Value;
            textBox15.Text = item.Element("Parent1Email").Value;
            textBox5.Text = item.Element("Parent2Name").Value;
            textBox6.Text = item.Element("Parent2Phone").Value;
            textBox7.Text = item.Element("Parent2Email").Value;
             

        }

        private void button2_Click(object sender, EventArgs e)
        {
            XDocument docx = XDocument.Load("XMLFile1.xml");
            //it creates a new element for the file
            XElement Tag = new XElement("item",
                new XElement("name", textBox8.Text),
                new XElement("nickname", textBox12.Text),
                new XElement("bunk", comboBox2.Text),
                new XElement("nationality", textBox9.Text),
                new XElement("startdate", textBox10.Text),
                new XElement("enddate", textBox11.Text),
                new XElement("age", textBox1.Text),
                new XElement("restriction", textBox2.Text),
                new XElement("medications", textBox3.Text),
                new XElement("transportation", textBox4.Text),
                new XElement("Parent1Name", textBox13.Text),
                new XElement("Parent1Phone", textBox14.Text),
                new XElement("Parent1Email", textBox15.Text),
                new XElement("Parent2Name", textBox5.Text),
                new XElement("Parent2Phone", textBox6.Text),
                new XElement("Parent2Email", textBox7)
                );
            docx.Element("data1").Add(Tag);
            
            docx.Save("XMLFILE1.xml");
            //saves the doc
            Form2_Load(sender, e);
            //reloads the form
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XDocument docx = XDocument.Load("XMLFile1.xml");
            var docxRead = docx.Elements("data1").Elements("item");
            var item = docxRead.Where(a => a.Element("name").Value == comboBox1.Text).Single();
            //change camper information
            item.Element("name").Value = textBox8.Text;
            item.Element("nickname").Value = textBox12.Text;
            item.Element("bunk").Value = comboBox2.Text;
            item.Element("age").Value = textBox1.Text;
            item.Element("nationality").Value = textBox9.Text;
            item.Element("restriction").Value = textBox2.Text;
            item.Element("medications").Value = textBox3.Text;
            item.Element("transportation").Value = textBox4.Text;
            item.Element("startdate").Value = textBox10.Text;
            item.Element("enddate").Value = textBox11.Text;
            item.Element("nameParent1").Value = textBox13.Text;
            item.Element("phoneParent1").Value = textBox14.Text;
            item.Element("emailParent1").Value = textBox15.Text;
            item.Element("nameParent2").Value = textBox5.Text;
            item.Element("phoneParent2").Value = textBox6.Text;
            item.Element("emailParent2").Value = textBox7.Text;

            //saving the doc that has been edited or changed
            docx.Save("XMLFile1.xml");
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            XDocument docx = XDocument.Load("XMLFile1.xml");
            var docxRead = docx.Elements("data1").Elements("item");
            //delets the items in the combobox
            docxRead.Where(y => y.Element("name").Value == comboBox1.Text).Single().Remove();
            docx.Save("XMLFile1.xml");
            //saves the document
        
            Form2_Load(sender, e);
            //Reloads the Second form

        }
    }
}
