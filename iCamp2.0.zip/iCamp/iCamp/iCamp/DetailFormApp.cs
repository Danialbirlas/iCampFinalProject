﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace iCamp
{
    public partial class DetailFormApp : Form
    {
        public DetailFormApp()
        {
            InitializeComponent();
            richTextBox1.Text = "This application allows students to sign up their personal information into the application's database and allows user to register for activities. Users can add and delete their info and re-add it. This is ICamp ";
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
