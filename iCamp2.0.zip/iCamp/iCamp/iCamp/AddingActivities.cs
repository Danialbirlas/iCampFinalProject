﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace iCamp
{
    public partial class AddingActivities : Form
    {
        public AddingActivities()
        {
            InitializeComponent();
        }

        private void AddingActivities_Load(object sender, EventArgs e)
        {
            LoadXML();
        }

        private void LoadXML()
        {
            XDocument docx = XDocument.Load("XMLFile3.xml");

            var docxread = docx.Elements("data1").Elements("date").Where(y => y.Element("value").Value.Equals(dateTimePicker1.Value.ToString("year-MM-dd"))).Elements("activity");
            // var docxRead = docx.Elements("data1").Elements("date").Where(y => y.Element("value").Value == "").Elements("activity");

            MessageBox.Show(docx.Elements("data1").Elements("date").ElementAt(0).ToString());

            if (docxread.Count() > 0)
            {
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                listBox3.Items.Clear();
                listBox4.Items.Clear();
                listBox5.Items.Clear();
                int count = 0;
                foreach (var z in docxread)
                {
                    foreach (var y in z.Elements("name"))
                    {
                        switch(count)
                        {
                            case 0:
                                listBox1.Items.Add(y.Value);
                                break;

                            case 1:
                                listBox2.Items.Add(y.Value);
                                break;

                            case 2:
                                listBox3.Items.Add(y.Value);
                                break;

                            case 3:
                                listBox4.Items.Add(y.Value);
                                break;

                            case 4:
                                listBox5.Items.Add(y.Value);
                                break;

                        }
                    }
                    count++;
                }
            }
            else
            {
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                listBox3.Items.Clear();
                listBox4.Items.Clear();
                listBox5.Items.Clear();
                listBox1.Items.Add("Drama");
                listBox2.Items.Add("Drawing");
                listBox3.Items.Add("Carpenting");
                listBox4.Items.Add("Football");
                listBox5.Items.Add("Softball");
            }
        }

        private void saveXml(int j, string b)
        {
            XDocument docx = XDocument.Load("XMLFile3.xml");
            XElement root = docx.Root;
            var docxread = docx.Elements("data1").Elements("date").Elements("activity");
            int count = 0;
            foreach ( var a in docxread)
            {
                if (count == j)
                {
                    a.Add(new XElement("name", j));

                }
                count++;
            }
            docx.Save("XMLFile3.xml");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string x = comboBox1.SelectedItem.ToString(); // session activity
            string y = textBox1.Text; // name of the activity

            switch (x){
                case "listBox1": {
                        saveXml(0, y);
                        listBox1.Items.Add(y);
                        break;
                    }

                case "listBox2": {
                        saveXml(1, y);
                        listBox2.Items.Add(y);
                        break;
                    }

                case "listBox3": {

                        saveXml(2, y);
                        listBox3.Items.Add(y);
                        break;
                    }
                case "listBox4": {
                        saveXml(3, y);
                        listBox4.Items.Add(y);
                        break;
                    }
                case "listBox5": {
                        saveXml(3, y);
                        listBox5.Items.Add(y);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        private void delete_click(object sender, EventArgs e)
        {
            Button delete = (Button)sender;
            int tyu = Convert.ToInt16(delete.Tag) - 1;


            ListBox[] listboxlist = { listBox1, listBox2, listBox3, listBox4, listBox5 };
            XDocument docx = XDocument.Load("XMLFile3.xml");
            var docxread = docx.Elements("data1").Elements("date").Elements("activity");
            int count = 0;
            foreach (var a in docxread)
            {
                if (count == tyu)
                {
                    a.Elements("name").Where(x => x.Value == listboxlist[tyu].Text).Single().Remove();
                    listboxlist[tyu].Items.RemoveAt(listboxlist[tyu].SelectedIndex);
                    a.Elements("data1").Elements("date").Where(x => x.Element("name").Value == comboBox1.Text).Single().Remove();

                }
                count++;
            }
            docx.Save("XMLFile3.xml");
        }
    }
}
