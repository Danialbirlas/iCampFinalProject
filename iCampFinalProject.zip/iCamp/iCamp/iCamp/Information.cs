﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace iCamp
{
   public class Information
    {
        private string data1;
        private string data2;
        private string data3;
        private string data4;
        private string data5;
        private string data6;
        private string data7;
        private string data8;
        private string data9;
        private string data10;
        private string data11;
        private string data12;
        private string data13;
        private string data14;
        private string data15;
        private string data16;
        


        public string Name
        {
            get { return data1; }
            set { data1 = value; }
        }
        public string Bunk
        {
            get { return data2; }
            set { data2 = value; }
        }
        public string Nationality
        {
            get { return data3; }
            set { data3 = value; }

        }

        public string StartDate
        {
            get { return data4; }
            set { data4 = value; }
        }

        public string LeaveDate
        {
            get { return data5; }
            set { data5 = value; }
        }
       
        public string PreferredName
        {
            get { return data6; }
            set { data6 = value; }
        }

        public string Age
        {
            get { return data7; }
            set { data7 = value; }
        }
        public string Restriction
        {
            get { return data8; }
            set { data8 = value; }
        }

        public string Medications
        {
            get { return data9; }
            set { data9 = value; }
        }
        
        public string Transportation
        {
            get { return data10; }
            set { data10 = value; }
        }

        public string Name1
        {
            get { return data11; }
            set { data11 = value; }
        }

        public string PhoneNo1
        {
            get { return data12; }
            set { data12 = value; }
        }

        public string Email1
        {
            get { return data13; }
            set { data13 = value; }
        }

        public string Name2
        {
            get { return data14; }
            set { data14 = value; }
        }

        public string PhoneNo2
        { get { return data15; }
            set { data15 = value; }

        }
        public string Email2
        {
            get { return data16; }
            set { data16 = value; }
        }

    }
}
